create trigger INVST_BIR
    before insert
    on INVESTMENT
    for each row
BEGIN
  SELECT invst_seq.NEXTVAL
  INTO   :new.invstid
  FROM   dual;
END;
/

